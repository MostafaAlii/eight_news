import Switch from './switch'

export default Switch;